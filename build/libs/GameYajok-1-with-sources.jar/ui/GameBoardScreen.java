package ui;

import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import java.net.URL;
import game.GameController;
import model.*;
import model.cards.Card;
import javafx.animation.KeyFrame;
import javafx.animation.PauseTransition;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.squares.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Represents the main game board screen where the gameplay takes place.
 * <p>
 * This class handles:
 * <ul>
 * <li>Rendering the board grid and squares (Properties, Special Squares).</li>
 * <li>Visualizing player tokens and movement animations.</li>
 * <li>Managing player turns, dice rolling, and interactions via Dialogs.</li>
 * <li>Handling game events (buying property, paying rent, cards, jail).</li>
 * <li>Displaying the "Game Over" screen.</li>
 * </ul>
 * </p>
 */
public class GameBoardScreen {
    private final Stage primaryStage;
    private final GameController gameController;
    private final Board board;
    private final List<Player> players;
    private final List<Integer> selectedCharIndices;

    private Label player1MoneyLabel;
    private Label player2MoneyLabel;
    private Label playerTurnLabel;

    private AudioClip winSound;

    private final List<ImageView> playerTokens;
    private final GridPane boardGrid;

    // Constants
    private static final String[] CHARACTER_FILES = {
            "character_01.png", "character_02.png", "character_03.png","character_04.png", "character_05.png", "character_06.png"
    };
    private static final String RESOURCE_PATH = "/Character/";
    private static final int MOVEMENT_DELAY_MS = 300;
    private static final String ICON_PATH = "/Image/";

    // Screen Size
    private static final int WIDTH = 1000;
    private static final int HEIGHT = 800;

    /**
     * Constructs the GameBoardScreen.
     *
     * @param primaryStage       The main stage.
     * @param gameController     The core game logic controller.
     * @param players            The list of players participating.
     * @param selectedCharIndices The indices of the character avatars selected by the players.
     */
    public GameBoardScreen(Stage primaryStage, GameController gameController, List<Player> players, List<Integer> selectedCharIndices) {
        this.primaryStage = primaryStage;
        this.gameController = gameController;
        this.board = gameController.getBoard();
        this.players = gameController.getPlayers();
        this.selectedCharIndices = selectedCharIndices;

        this.playerTokens = new ArrayList<>();
        this.boardGrid = createBoardGrid();
        initializePlayerTokens();
    }

    /**
     * Initializes the visual tokens (character images) for all players.
     * <p>
     * This method creates {@link ImageView} instances for each player based on their selected character.
     * It configures the token size, assigns a unique ID for CSS styling, and applies a colored
     * {@link DropShadow} effect (LimeGreen for Player 1, Red for Player 2) to help distinguish
     * players visually on the board. The created tokens are then added to the {@code playerTokens} list.
     * </p>
     */
    private void initializePlayerTokens() {
        Color[] shadowColors = {Color.LIMEGREEN, Color.RED};

        for (int i = 0; i < players.size(); i++) {
            ImageView token = createCharacterImageView(selectedCharIndices.get(i));
            token.setFitWidth(30);
            token.setFitHeight(30);
            token.setId("player-token-" + i);

            if (i < shadowColors.length) {
                DropShadow dropShadow = new DropShadow();
                dropShadow.setColor(shadowColors[i]);
                dropShadow.setRadius(8.0);
                dropShadow.setSpread(0.4);
                dropShadow.setOffsetX(0);
                dropShadow.setOffsetY(0);
                token.setEffect(dropShadow);
            }
            playerTokens.add(token);
        }
    }

    /**
     * Creates and returns the main gameplay scene.
     * <p>
     * Sets up the board layout, player status panels, roll button, and event listeners.
     * </p>
     *
     * @return The gameplay {@link Scene}.
     */
    public Scene createGameScene() {
        SoundManager.playBGM("board.mp3");

        BorderPane root = new BorderPane();
        root.getStyleClass().add("game-background");

        // Roll Button
        Button rollButton = new Button("Roll Dice!");
        rollButton.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        rollButton.setMinWidth(150);
        rollButton.setMinHeight(150);
        rollButton.setId("roll-button");
        rollButton.setOnAction(e -> {
            rollButton.setDisable(true);
            startTurnAndAnimate(rollButton);
            //playDiceSound();
        });

        // Player Turn Label
        playerTurnLabel = new Label("Turn: " + gameController.getCurrentPlayer().getName());
        playerTurnLabel.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        playerTurnLabel.setStyle("-fx-text-fill: #333333;");

        VBox centerControl = new VBox(10, playerTurnLabel, rollButton);
        centerControl.setAlignment(Pos.CENTER);

        StackPane centerStack = new StackPane(boardGrid, centerControl);
        root.setCenter(centerStack);

        // Player Panels
        if (players.size() >= 1) {
            HBox player1Panel = createPlayerPanel(players.get(0), selectedCharIndices.get(0), true);
            root.setTop(player1Panel);
            BorderPane.setAlignment(player1Panel, Pos.TOP_LEFT);
            BorderPane.setMargin(player1Panel, new Insets(10));
        }

        if (players.size() >= 2) {
            HBox player2Panel = createPlayerPanel(players.get(1), selectedCharIndices.get(1), false);
            root.setBottom(player2Panel);
            BorderPane.setAlignment(player2Panel, Pos.BOTTOM_RIGHT);
            BorderPane.setMargin(player2Panel, new Insets(10));
        }

        updatePlayerTokens();
        updateTurnDisplay(rollButton);

        Scene gameScene = new Scene(root, WIDTH, HEIGHT);

        // --- CHEAT MODE: Keyboard listener (1-6) to force dice result ---
        gameScene.setOnKeyPressed(event -> {
            if (event.getCode().isDigitKey()) {
                try {
                    int steps = Integer.parseInt(event.getCode().getChar());
                    if (steps >= 1 && steps <= 6) {
                        handleTestMove(steps);
                        event.consume();
                    }
                } catch (NumberFormatException e) {
                    // ignore
                }
            }
        });

        try {
            gameScene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());
        } catch (NullPointerException e) {
            System.err.println("Warning: Could not load style.css. Ensure it is in the resource path.");
        }
        return gameScene;
    }

    // =========================================================================
    // *** Turn Management Logic ***
    // =========================================================================

    /**
     * Starts the turn for the current player.
     * <p>
     * Checks for Jail or Skip Turn status before allowing the player to roll the dice.
     * </p>
     *
     * @param rollButton The main roll button (passed to control its disabled state).
     */
    private void startTurnAndAnimate(Button rollButton) {
        Player activePlayer = gameController.getCurrentPlayer();

        // 1. Check Jail Status
        if (activePlayer.isInJail()) {
            handleJailTurn(activePlayer, rollButton);
            return;
        }

        // 2. Check Skip Turn Status
        if (activePlayer.getSkipTurns() > 0) {
            showSkipTurnDialog(activePlayer, rollButton);
            return;
        }

        // 3. Proceed to Roll
        executeRollAndMove(activePlayer, rollButton);
    }

    /**
     * Manages the turn logic for a player who is currently in Jail.
     * <p>
     * Displays a confirmation dialog offering the player two choices:
     * <ul>
     * <li><b>Pay $200:</b> If the player has sufficient funds, the bail is deducted,
     * they are released immediately, and they proceed to roll the dice (taking their turn normally).</li>
     * <li><b>Wait:</b> The player chooses to serve their sentence (or cannot afford bail).
     * This delegates logic to {@link #processWaitInJail(Player, Button)}.</li>
     * </ul>
     * </p>
     *
     * @param player     The player whose turn it is.
     * @param rollButton The roll dice button (needed to re-enable UI or pass to movement logic).
     */
    private void handleJailTurn(Player player, Button rollButton) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("In Jail");
        alert.setHeaderText("You are in Jail!");
        alert.setContentText("Turns left: " + player.getJailTurns() + "\nChoose an action:");

        ButtonType payButton = new ButtonType("Pay $200");
        ButtonType waitButton = new ButtonType("Wait");
        alert.getButtonTypes().setAll(payButton, waitButton);

        styleDialog(alert);

        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == payButton) {
            if (player.deductMoney(200)) {
                player.releaseFromJail();
                refreshAllPlayersMoney();
                showSimpleAlert("Released!", "You paid $200 bail. You can move now!");

                // Move immediately after paying
                executeRollAndMove(player, rollButton);
            } else {
                showSimpleAlert("Error", "Not enough money to pay bail!");
                processWaitInJail(player, rollButton);
            }
        } else {
            processWaitInJail(player, rollButton);
        }
    }

    /**
     * Processes the logic when a player remains in jail (either by choice or lack of funds).
     * <p>
     * Decrements the player's remaining jail sentence counter.
     * <ul>
     * <li>If the remaining turns reach 0, the player is released and will be free on their <b>next</b> turn.</li>
     * <li>Otherwise, the player remains incarcerated.</li>
     * </ul>
     * In both cases, the current turn ends immediately without rolling the dice.
     * </p>
     *
     * @param player     The player currently in jail.
     * @param rollButton The roll dice button (used to finalize the turn state).
     */
    private void processWaitInJail(Player player, Button rollButton) {
        player.decrementJailTurns();

        if (player.getJailTurns() <= 0) {
            player.releaseFromJail();
            showSimpleAlert("Time served", "You served your time. Next turn you will be free.");
        } else {
            showSimpleAlert("Stay in Jail", "You are still in jail. Turns left: " + player.getJailTurns());
        }
        endTurn(player, rollButton);
    }

    /**
     * Animates the dice roll and triggers the movement sequence.
     *
     * @param activePlayer The player taking the turn.
     * @param rollButton   The UI button to update with the dice result.
     */
    private void executeRollAndMove(Player activePlayer, Button rollButton) {
        playDiceSound();

        Timeline diceAnimation = new Timeline();
        diceAnimation.setCycleCount(15);

        diceAnimation.getKeyFrames().add(new KeyFrame(Duration.millis(50), e -> {
            int randomFace = (int)(Math.random() * 6) + 1;
            rollButton.setText(String.valueOf(randomFace));
        }));

        diceAnimation.setOnFinished(e -> {
            int actualSteps = gameController.getDice().roll();
            System.out.println(activePlayer.getName() + " rolled a " + actualSteps);

            rollButton.setText(String.valueOf(actualSteps));

            PauseTransition pause = new PauseTransition(Duration.seconds(0.5));
            pause.setOnFinished(event -> {
                // Proceed to movement animation
                animateMovement(activePlayer, actualSteps, rollButton);
            });
            pause.play();
        });

        diceAnimation.play();
    }

    /**
     * Displays a dialog informing the player that they must skip their current turn.
     * <p>
     * This method performs the following actions:
     * <ul>
     * <li>Shows an information alert indicating how many skip turns remain.</li>
     * <li>Decrements the player's skip turn counter by 1.</li>
     * <li>Automatically advances the game to the next player's turn after the user acknowledges the dialog.</li>
     * <li>Updates the turn display UI to reflect the next player.</li>
     * </ul>
     * </p>
     *
     * @param player     The player who is skipping the turn.
     * @param rollButton The roll button, passed to {@link #updateTurnDisplay(Button)} to refresh the UI state.
     */
    private void showSkipTurnDialog(Player player, Button rollButton) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Skip Turn");
        alert.setHeaderText(player.getName() + " must skip turn!");
        alert.setContentText("You have " + player.getSkipTurns() + " turn(s) left to skip.");

        styleDialog(alert);

        player.setSkipTurns(player.getSkipTurns() - 1);
        alert.showAndWait();

        gameController.moveToNextPlayer();
        updateTurnDisplay(rollButton);
    }

    /**
     * Animates the player token moving step-by-step across the board.
     *
     * @param player     The player moving.
     * @param steps      The number of steps to move.
     * @param rollButton The button to re-enable after movement.
     */
    private void animateMovement(Player player, int steps, Button rollButton) {
        Timeline timeline = new Timeline();
        int boardSize = gameController.getBoard().getBoardSize();

        for (int i = 1; i <= steps; i++) {
            final int step = i;
            KeyFrame keyFrame = new KeyFrame(
                    Duration.millis(MOVEMENT_DELAY_MS * step),
                    event -> {
                        int oldPosition = player.getPosition();
                        int newPosition = (oldPosition + 1) % boardSize;

                        player.warp(newPosition);

                        if (newPosition == 0 && oldPosition != 0) {
                            player.addMoney(100);
                            refreshAllPlayersMoney();
                            System.out.println(player.getName() + " passed Go! Collected $100.");
                        }
                        updatePlayerTokens();
                    }
            );
            timeline.getKeyFrames().add(keyFrame);
        }

        timeline.setOnFinished(event -> {
            Platform.runLater(() -> {
                handleLandedSquareInteraction(player, rollButton);
                Square currentSquare = board.getSquare(player.getPosition());

                playSquareSound(currentSquare);

                rollButton.setDisable(false);
            });
        });

        timeline.play();
    }

    // =========================================================================
    // *** Central Interaction Hub ***
    // =========================================================================

    /**
     * Determines the type of square landed on and delegates to the appropriate handler method.
     * <p>
     * This method acts as a central dispatcher for game logic interactions (Polymorphism in action).
     * </p>
     *
     * @param player     The player who landed.
     * @param rollButton The button control.
     */
    private void handleLandedSquareInteraction(Player player, Button rollButton) {
        Square landedSquare = board.getSquare(player.getPosition());
        System.out.println(">>> Handling interaction at: " + landedSquare.getName() + " [" + player.getPosition() + "]");

        landedSquare.landOn(player);
        refreshAllPlayersMoney();


        if (landedSquare instanceof Rentable) {
            handleRentableAction(player, landedSquare, rollButton);
        } else if (landedSquare instanceof CardSquare) {
            handleCardAction(player, rollButton);
        } else if (landedSquare instanceof AirplaneSquare) {
            handleAirplaneAction(player, rollButton);
        } else {
            handleGeneralSquareAction(player, landedSquare, rollButton);
        }
    }


    private void handleCardAction(Player player, Button rollButton) {
        int oldPosition = player.getPosition();

        Card drawnCard = gameController.getCardManager().drawCard();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Draw Card");
        alert.setHeaderText("You drew a card!");
        alert.setContentText("Effect: " + drawnCard.getDescription());

        styleDialog(alert);
        alert.showAndWait();

        drawnCard.execute(player, board);

        refreshAllPlayersMoney();
        updatePlayerTokens();

        // Recursion Check: If the card moved the player, trigger interaction for the new square
        int newPosition = player.getPosition();
        if (newPosition != oldPosition) {
            System.out.println(">> Player moved by card. Triggering new square interaction...");
            handleLandedSquareInteraction(player, rollButton);
        } else {
            endTurn(player, rollButton);
        }
    }

    private void handleAirplaneAction(Player player, Button rollButton) {
        List<Square> allSquares = board.getSquares();
        List<String> choices = allSquares.stream()
                .map(s -> "[" + s.getPosition() + "] " + s.getName())
                .collect(Collectors.toList());

        ChoiceDialog<String> dialog = new ChoiceDialog<>(choices.get(0), choices);
        dialog.setTitle("Airplane Flight");
        dialog.setHeaderText("Welcome to the Airport!");
        dialog.setContentText(player.getName() + ", choose your destination:");

        styleDialog(dialog);

        Optional<String> result = dialog.showAndWait();

        if (result.isPresent()) {
            int targetPosition = Integer.parseInt(result.get().split("]")[0].substring(1));
            gameController.handleAirplaneAction(player, targetPosition);

            updatePlayerTokens();
            refreshAllPlayersMoney();

            // Recursion: Land on new square
            handleLandedSquareInteraction(player, rollButton);

        } else {
            showSimpleAlert("Flight Cancelled", "You chose to stay at the airport.");
            endTurn(player, rollButton);
        }
    }

    private void handleGeneralSquareAction(Player player, Square landedSquare, Button rollButton) {
        if (landedSquare instanceof TaxSquare) {
            TaxSquare taxSq = (TaxSquare) landedSquare;
            showSimpleAlert("Tax", "You paid tax! Amount: $" + taxSq.getLastTaxPaid());

        } else if (landedSquare instanceof LotterySquare) {
            LotterySquare lotterySq = (LotterySquare) landedSquare;
            showSimpleAlert("Lottery", "You won the lottery! Prize: $" + lotterySq.getLastPrize());

        } else if (landedSquare instanceof JailSquare) {
            if (player.isInJail()) {
                showSimpleAlert("Jail", "You are in Jail!");
            }
        }

        endTurn(player, rollButton);
    }

    // =========================================================================
    // *** Helper Methods & UI Utilities ***
    // =========================================================================

    private void endTurn(Player player, Button rollButton) {
        checkBankruptcy(player);
        gameController.moveToNextPlayer();
        updateTurnDisplay(rollButton);
    }

    private void showBuyPropertyDialog(Player player, Property property, Button rollButton) {
        int price = property.getPrice();

        if (player.getMoney() >= price) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Buy Property");
            alert.setHeaderText("Unowned Property: " + property.getName());
            alert.setContentText("Price: $" + price + ". Would you like to buy it?");

            styleDialog(alert);

            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                if (player.deductMoney(price)) {
                    property.setOwner(player);
                    updateSquareBox(property);
                }
            }
        } else {
            showSimpleAlert("Cannot Afford", property.getName() + " costs $" + price + ". You do not have enough money to buy it.");
        }

        refreshAllPlayersMoney();
        endTurn(player, rollButton);
    }

    private void showBuyIslandDialog(Player player, IslandSquare island, Button rollButton) {
        int price = island.getPrice();

        if (player.getMoney() >= price) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Buy Island");
            alert.setHeaderText("🏝️ Unowned Island: " + island.getName());
            alert.setContentText("Price: $" + price + "\nRent: $" + island.getRent() + "\n\nWould you like to buy it?");
            styleDialog(alert);

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                if (player.deductMoney(price)) {
                    island.setOwner(player);
                    updateSquareBox(island);
                }
            }
        } else {
            showSimpleAlert("Cannot Afford", island.getName() + " costs $" + price + ". You do not have enough money.");
        }

        refreshAllPlayersMoney();
        endTurn(player, rollButton);
    }

    private void showUpgradePropertyDialog(Player player, Property property, Button rollButton) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Upgrade Property");
        alert.setHeaderText("Your Property: " + property.getName());
        alert.setContentText("Upgrade to Landmark? Cost: $" + property.getUpgradeCost() + ". (Rent x3)");

        styleDialog(alert);

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

            int cost = property.getUpgradeCost();

            if (player.getMoney() >= cost) {
                if (player.deductMoney(cost)) {
                    property.setLandmark(true);
                    updateSquareBox(property);
                }
            } else {
                showSimpleAlert("Upgrade Failed", "Not enough money to upgrade! (Cost: $" + cost + "). Upgrade is cancelled.");
            }
            refreshAllPlayersMoney();
        }

        endTurn(player, rollButton);
    }

    private void refreshAllPlayersMoney() {
        for (Player p : players) {
            updatePlayerMoney(p);
        }
    }

    private void checkBankruptcy(Player player) {
        if (player.getMoney() <= 0) {
            showGameOverScreen(player);
        }
    }

    /**
     * Displays the Game Over screen.
     * <p>
     * Stops the BGM, plays a victory sound, and shows the winner/loser logic
     * (based on the Inverse Monopoly rule: First to Bankrupt wins).
     * </p>
     *
     * @param bankruptPlayer The player who went bankrupt (the Winner).
     */
    private void showGameOverScreen(Player bankruptPlayer) {
        SoundManager.stopBGM();

        try {
            URL url = getClass().getResource("/soundfx/win.mp3");
            if (url != null) {
                if (winSound != null) winSound.stop();
                winSound = new AudioClip(url.toExternalForm());
                winSound.setVolume(0.5);
                winSound.play();
            }
        } catch (Exception e) { System.err.println("Win sound error: " + e.getMessage()); }

        Player winner = bankruptPlayer; // Winner is the first one to go bankrupt
        Player loser = players.stream()
                .filter(p -> p != winner)
                .findFirst()
                .orElse(winner);

        VBox layout = new VBox(20);
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: #2c3e50; -fx-padding: 40;");

        Label headerLabel = new Label("🏆 GAME OVER 🏆");
        headerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 48));
        headerLabel.setTextFill(Color.GOLD);

        Label winnerLabel = new Label(winner.getName() + " WINS!");
        winnerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        winnerLabel.setTextFill(Color.WHITE);

        Label subLabel = new Label("ไม่เหลืออะไรแล้วชึวิต ลาก่อน...");
        subLabel.setFont(Font.font("Arial", 18));
        subLabel.setTextFill(Color.LIGHTGRAY);

        // Winner Image
        int playerIndex = players.indexOf(winner);
        int charIndex = selectedCharIndices.get(playerIndex);
        ImageView winnerImage = createCharacterImageView(charIndex);
        winnerImage.setFitWidth(200);
        winnerImage.setFitHeight(200);
        winnerImage.setEffect(new DropShadow(20, Color.BLACK));

        // Buttons
        Button playAgainBtn = new Button("Play Again");
        playAgainBtn.setPrefSize(150, 50);
        playAgainBtn.setStyle("-fx-font-size: 18px; -fx-background-color: #27ae60; -fx-text-fill: white; -fx-cursor: hand;");

        Button exitBtn = new Button("Exit Game");
        exitBtn.setPrefSize(150, 50);
        exitBtn.setStyle("-fx-font-size: 18px; -fx-background-color: #c0392b; -fx-text-fill: white; -fx-cursor: hand;");

        playAgainBtn.setOnAction(e -> {
            if (winSound != null) {
                winSound.stop();
            }
            GameController newGame = new GameController();
            CharacterSelectScreen selectScreen = new CharacterSelectScreen(primaryStage, newGame);
            primaryStage.setScene(selectScreen.createCharacterSelectScene());
        });

        exitBtn.setOnAction(e -> {
            Platform.exit();
            System.exit(0);
        });

        HBox buttonsBox = new HBox(20, playAgainBtn, exitBtn);
        buttonsBox.setAlignment(Pos.CENTER);

        layout.getChildren().addAll(headerLabel, winnerImage, winnerLabel, subLabel, buttonsBox);
        Scene gameOverScene = new Scene(layout, WIDTH, HEIGHT);
        primaryStage.setScene(gameOverScene);
    }

    private void showSimpleAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        styleDialog(alert);
        alert.showAndWait();
    }

    private void styleDialog(Dialog<?> dialog) {
        DialogPane dialogPane = dialog.getDialogPane();
        try {
            dialogPane.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());
            dialogPane.getStyleClass().add("game-dialog");
        } catch (Exception e) {
            System.err.println("Warning: Could not load style.css for dialog.");
        }
    }

    private void updateTurnDisplay(Button rollButton) {
        Player nextPlayer = gameController.getCurrentPlayer();
        playerTurnLabel.setText("Turn: " + nextPlayer.getName());

        rollButton.setText("Roll Dice!");
        rollButton.setDisable(false);

        Color playerColor = (nextPlayer == players.get(0)) ? Color.LIMEGREEN : Color.RED;
        playerTurnLabel.setStyle("-fx-text-fill: white; -fx-background-color: " + toHexString(playerColor) + "; -fx-padding: 5; -fx-border-radius: 5;");
    }

    private String toHexString(Color color) {
        return String.format("#%02X%02X%02X",
                (int) (color.getRed() * 255),
                (int) (color.getGreen() * 255),
                (int) (color.getBlue() * 255));
    }

    // =========================================================================
    // *** Board Rendering Logic ***
    // =========================================================================

    /**
     * Updates the position of player tokens on the grid.
     */
    public void updatePlayerTokens() {
        for (ImageView token : playerTokens) {
            if (token.getParent() instanceof StackPane) {
                ((StackPane) token.getParent()).getChildren().remove(token);
            }
        }

        for (int i = 0; i < players.size(); i++) {
            Player player = players.get(i);
            ImageView token = playerTokens.get(i);
            int currentPos = player.getPosition();

            int col = getColForPosition(currentPos);
            int row = getRowForPosition(currentPos);

            if (row != -1 && col != -1) {
                StackPane targetCell = getCellFromGrid(row, col);
                if (targetCell != null) {
                    targetCell.getChildren().add(token);
                    StackPane.setAlignment(token, i == 0 ? Pos.BOTTOM_LEFT : Pos.BOTTOM_RIGHT);
                }
            }
        }
    }

    private StackPane getCellFromGrid(int row, int intcol) {
        for (javafx.scene.Node node : boardGrid.getChildren()) {
            Integer nodeCol = GridPane.getColumnIndex(node);
            Integer nodeRow = GridPane.getRowIndex(node);
            if (nodeCol != null && nodeRow != null && nodeCol == intcol && nodeRow == row) {
                if (node instanceof StackPane) {
                    return (StackPane) node;
                }
            }
        }
        return null;
    }

    private VBox createSquareBox(Square square, int index) {
        Label indexLabel = new Label("#" + index);
        indexLabel.setFont(Font.font("Arial", FontWeight.BOLD, 10));
        indexLabel.setTextFill(Color.web("#333333"));

        Label title = new Label(square.getName());
        title.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        title.setWrapText(true);
        title.setAlignment(Pos.CENTER);

        ImageView iconView = createSquareIcon(square);

        VBox box = new VBox(2);
        box.getChildren().add(indexLabel);
        if (iconView != null) {
            box.getChildren().add(iconView);
        }
        box.getChildren().add(title);

        box.setAlignment(Pos.CENTER);
        box.setPrefSize(100, 100);

        updateSquareBoxStyle(box, square);

        box.setBorder(new Border(new BorderStroke(
                Color.BLACK,
                BorderStrokeStyle.SOLID,
                new CornerRadii(10),
                new BorderWidths(1)
        )));

        return box;
    }

    private void updateSquareBoxStyle(VBox box, Square square) {
        String backgroundColor = "#FFFFFF";
        String borderColor = "#000000";

        if (square.getPosition() == 0) {
            backgroundColor = "#AAFFAA"; // Go
        } else if (square instanceof JailSquare) {
            backgroundColor = "#ADD8E6"; // Jail
        } else if (square instanceof CardSquare) {
            backgroundColor = "#F08080"; // Card
        } else if (square instanceof AirplaneSquare) {
            backgroundColor = "#A9A9A9"; // Airport
        } else if (square instanceof LotterySquare) {
            backgroundColor = "#FFFF99"; // Lottery
        }
        // === START: โค้ดสำหรับ IslandSquare (เพิ่มเข้ามา) ===
        else if (square instanceof IslandSquare) {
            IslandSquare island = (IslandSquare) square;
            if (island.getOwner() != null) {
                // กำหนดสีพื้นหลังและสีขอบตามสี Property ที่กำหนด
                if (island.getOwner() == players.get(0)) {
                    backgroundColor = "#E6FFE6";
                    borderColor = "#2E8B57";
                } else if (players.size() > 1 && island.getOwner() == players.get(1)) {
                    backgroundColor = "#FFE6E6";
                    borderColor = "#FF6347";
                }
                // *ไม่ใส่ box.setBorder(...) ตรงนี้ ตามที่คุณต้องการ*
            }
        }
        // === END: โค้ดสำหรับ IslandSquare ===
        else if (square instanceof Property) {
            Property property = (Property) square;
            if (property.getOwner() != null) {
                if (property.getOwner() == players.get(0)) {
                    backgroundColor = "#E6FFE6";
                    borderColor = "#2E8B57";
                } else if (players.size() > 1 && property.getOwner() == players.get(1)) {
                    backgroundColor = "#FFE6E6";
                    borderColor = "#FF6347";
                }

                if (property.isLandmark()) {
                    borderColor = "#FFD700";
                    box.setBorder(new Border(new BorderStroke(
                            Color.web(borderColor),
                            BorderStrokeStyle.SOLID,
                            new CornerRadii(10),
                            new BorderWidths(4)
                    )));
                } else {
                    box.setBorder(new Border(new BorderStroke(
                            Color.web(borderColor),
                            BorderStrokeStyle.SOLID,
                            new CornerRadii(10),
                            new BorderWidths(2)
                    )));
                }
            } else {
                box.setBorder(new Border(new BorderStroke(
                        Color.BLACK,
                        BorderStrokeStyle.SOLID,
                        new CornerRadii(10),
                        new BorderWidths(1)
                )));
            }
        }

        box.setStyle("-fx-background-color: " + backgroundColor + ";");
    }

    private void updateSquareBox(Square square) {
        int row = getRowForPosition(square.getPosition());
        int col = getColForPosition(square.getPosition());
        int index = square.getPosition();

        StackPane cell = getCellFromGrid(row, col);

        if (cell != null && !cell.getChildren().isEmpty() && cell.getChildren().get(0) instanceof VBox) {
            VBox squareBox = (VBox) cell.getChildren().get(0);
            squareBox.getChildren().clear();

            Label indexLabel = new Label("#" + index);
            indexLabel.setFont(Font.font("Arial", FontWeight.BOLD, 10));
            indexLabel.setTextFill(Color.web("#333333"));
            squareBox.getChildren().add(indexLabel);

            ImageView iconView = createSquareIcon(square);
            Label title = new Label(square.getName());
            title.setFont(Font.font("Arial", FontWeight.BOLD, 12));
            title.setWrapText(true);
            title.setAlignment(Pos.CENTER);

            if (iconView != null) {
                squareBox.getChildren().add(iconView);
            }
            squareBox.getChildren().add(title);

            updateSquareBoxStyle(squareBox, square);
        }
    }

    private GridPane createBoardGrid() {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);

        int dim = 6;
        for (int row = 0; row < dim; row++) {
            for (int col = 0; col < dim; col++) {
                int squareIndex = getIndexFromGrid(row, col, dim);
                StackPane cell = new StackPane();
                cell.setPrefSize(100, 100);

                if (squareIndex != -1 && squareIndex < board.getBoardSize()) {
                    Square square = board.getSquare(squareIndex);
                    VBox squareBox = createSquareBox(square, squareIndex);
                    cell.getChildren().add(squareBox);
                    cell.setAlignment(Pos.CENTER);
                    cell.setId("square-cell-" + squareIndex);
                } else {
                    cell.setBackground(Background.EMPTY);
                    cell.setBorder(Border.EMPTY);
                }
                grid.add(cell, col, row);
            }
        }
        return grid;
    }

    private int getIndexFromGrid(int row, int col, int dim) {
        if (row == dim - 1) return dim - 1 - col;
        if (col == 0 && row >= 1 && row <= 4) return dim - 1 - row + 5;
        if (row == 0 && col >= 0 && col <= 5) return col + 10;
        if (col == dim - 1 && row >= 1 && row <= 4) return row + 15;
        return -1;
    }

    private int getRowForPosition(int squareIndex) {
        int dim = 6;
        if (squareIndex >= 0 && squareIndex <= 5) return dim - 1;
        if (squareIndex >= 6 && squareIndex <= 9) return dim - 1 - (squareIndex - 5);
        if (squareIndex >= 10 && squareIndex <= 15) return 0;
        if (squareIndex >= 16 && squareIndex <= 19) return 1 + (squareIndex - 16);
        return -1;
    }

    private int getColForPosition(int squareIndex) {
        int dim = 6;
        if (squareIndex >= 0 && squareIndex <= 5) return dim - 1 - squareIndex;
        if (squareIndex >= 6 && squareIndex <= 9) return 0;
        if (squareIndex >= 10 && squareIndex <= 15) return squareIndex - 10;
        if (squareIndex >= 16 && squareIndex <= 19) return dim - 1;
        return -1;
    }

    private ImageView createCharacterImageView(int index) {
        ImageView imageView = new ImageView();
        try {
            String fileName = CHARACTER_FILES[index];
            String fullPath = RESOURCE_PATH + fileName;
            Image image = new Image(getClass().getResourceAsStream(fullPath));
            imageView.setImage(image);
            imageView.setFitWidth(50);
            imageView.setPreserveRatio(true);
        } catch (Exception e) {
            System.err.println("!!! ERROR: Character not found: " + CHARACTER_FILES[index]);
            imageView.setFitWidth(50);
        }
        return imageView;
    }

    private HBox createPlayerPanel(Player player, int charIndex, boolean isPlayer1) {
        ImageView charImageView = createCharacterImageView(charIndex);
        charImageView.setFitWidth(50);

        Label nameLabel = new Label(player.getName());
        nameLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));

        Label moneyLabel = new Label("Money: $" + player.getMoney());
        moneyLabel.setFont(Font.font("Arial", 16));

        if (isPlayer1) {
            this.player1MoneyLabel = moneyLabel;
        } else {
            this.player2MoneyLabel = moneyLabel;
        }

        VBox infoBox = new VBox(5, nameLabel, moneyLabel);
        infoBox.setAlignment(Pos.CENTER_LEFT);

        HBox panel = new HBox(10, charImageView, infoBox);
        panel.setAlignment(Pos.CENTER_LEFT);
        panel.setPadding(new Insets(10));
        panel.setBorder(new Border(new BorderStroke(
                Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(2)
        )));
        panel.setBackground(new Background(new BackgroundFill(
                isPlayer1 ? Color.LIGHTGREEN : Color.LIGHTCORAL,
                CornerRadii.EMPTY, Insets.EMPTY
        )));
        panel.setPrefWidth(250);

        return panel;
    }

    public void updatePlayerMoney(Player player) {
        Label targetLabel = null;
        if (player == players.get(0)) {
            targetLabel = player1MoneyLabel;
        } else if (players.size() > 1 && player == players.get(1)) {
            targetLabel = player2MoneyLabel;
        }

        if (targetLabel != null) {
            int oldMoney = getMoneyFromLabel(targetLabel);
            int newMoney = player.getMoney();

            if (oldMoney != newMoney) {
                playSound("lottery.mp3");
                targetLabel.setText("Money: $" + newMoney);
            }
        }
    }

    private ImageView createSquareIcon(Square square) {
        String fileName = null;

        if (square instanceof Property) {
            Property prop = (Property) square;
            if (prop.isLandmark()) {
                fileName = "landmark.png";
            } else if (prop.getOwner() != null) {
                fileName = "house.png";
            }
        } else if (square instanceof LotterySquare) {
            fileName = "ingots.png";
        } else if (square instanceof TaxSquare) {
            fileName = "bag.png";
        } else if (square instanceof JailSquare) {
            fileName = "jail.png";
        } else if (square instanceof IslandSquare) {
            IslandSquare island = (IslandSquare) square;
            if (island.getOwner() != null) {
                fileName = "island.png";
            }
        } else if (square instanceof AirplaneSquare) {
            fileName = "plane.png";
        } else if (square instanceof CardSquare) {
            fileName = "q.png";
        }

        if (fileName != null) {
            try {
                Image img = new Image(getClass().getResourceAsStream("/Image/" + fileName));
                ImageView view = new ImageView(img);
                view.setFitWidth(45);
                view.setFitHeight(45);
                view.setPreserveRatio(true);
                return view;
            } catch (Exception e) {
                System.err.println("!!! Error loading icon: " + fileName);
            }
        }
        return null;
    }

    private void playDiceSound() {
        try {
            URL soundResource = getClass().getResource("/soundfx/dice.mp3");
            if (soundResource != null) {
                AudioClip sound = new AudioClip(soundResource.toExternalForm());
                sound.setVolume(1.0);
                sound.play();
            } else {
                System.err.println("!!! Error: dice.mp3 not found");
            }
        } catch (Exception e) {
            System.err.println("Error playing sound: " + e.getMessage());
        }
    }

    private void playSound(String fileName) {
        try {
            URL soundResource = getClass().getResource("/soundfx/" + fileName);
            if (soundResource != null) {
                AudioClip sound = new AudioClip(soundResource.toExternalForm());
                sound.setVolume(1.0);
                sound.play();
            } else {
                System.err.println("!!! Sound not found: /soundfx/" + fileName);
            }
        } catch (Exception e) {
            System.err.println("Error playing sound [" + fileName + "]: " + e.getMessage());
        }
    }

    private void playSquareSound(Square square) {
        String soundFile = null;

        if (square instanceof CardSquare) {
            soundFile = "card.mp3";
        } else if (square instanceof JailSquare) {
            soundFile = "jail.mp3";
        } else if (square instanceof LotterySquare || square instanceof TaxSquare) {
            soundFile = "lottery.mp3";
        } else if (square instanceof AirplaneSquare) {
            soundFile = "plane.mp3";
        }

        if (soundFile != null) {
            try {
                URL soundResource = getClass().getResource("/soundfx/" + soundFile);
                if (soundResource != null) {
                    AudioClip sound = new AudioClip(soundResource.toExternalForm());
                    sound.setVolume(1.0);
                    sound.play();
                }
            } catch (Exception e) {
                System.err.println("!!! Error playing sound: " + e.getMessage());
            }
        }
    }

    private int getMoneyFromLabel(Label label) {
        try {
            String text = label.getText();
            if (text == null || text.isEmpty()) return 0;
            String numberOnly = text.replaceAll("[^0-9-]", "");
            return Integer.parseInt(numberOnly);
        } catch (Exception e) {
            return 0;
        }
    }

    private void handleTestMove(int steps) {
        Button rollButton = (Button) primaryStage.getScene().lookup("#roll-button");
        if (rollButton == null || rollButton.isDisable()) {
            return;
        }

        Player activePlayer = gameController.getCurrentPlayer();
        gameController.getDice().setForcedResult(steps);
        rollButton.setDisable(true);
        executeRollAndMove(activePlayer, rollButton);

        System.out.println("TEST MOVE: " + activePlayer.getName() + " forces roll to " + steps + " steps");
    }
    private void handleRentableAction(Player player, Square square, Button rollButton) {
        // Cast to Rentable (both Property and IslandSquare implement this)
        Rentable rentable = (Rentable) square;
        Player owner = null;

        // Get owner based on type
        if (square instanceof Property) {
            owner = ((Property) square).getOwner();
        } else if (square instanceof IslandSquare) {
            owner = ((IslandSquare) square).getOwner();
        }

        // Case 1: Someone else owns it - Pay Rent
        if (owner != null && owner != player) {
            handleRentPayment(player, square, rentable, owner, rollButton);

            // Case 2: Player owns it - Upgrade (Property only)
        } else if (owner == player) {
            if (square instanceof Property) {
                Property property = (Property) square;
                if (!property.isLandmark()) {
                    showUpgradePropertyDialog(player, property, rollButton);
                } else {
                    endTurn(player, rollButton);
                }
            } else if (square instanceof IslandSquare) {
                // Island: Just visiting, no upgrades
                showSimpleAlert("Your Island", "Welcome back to your island: " + square.getName() + "!");
                endTurn(player, rollButton);
            }

            // Case 3: Unowned - Buy
        } else {
            if (square instanceof Property) {
                showBuyPropertyDialog(player, (Property) square, rollButton);
            } else if (square instanceof IslandSquare) {
                showBuyIslandDialog(player, (IslandSquare) square, rollButton);
            }
        }
    }

    private void handleRentPayment(Player player, Square square, Rentable rentable, Player owner, Button rollButton) {

        int rent = rentable.calculateRent(0);

        String squareType = (square instanceof IslandSquare) ? "🏝️ Island" : "Property";

        Alert rentAlert = new Alert(Alert.AlertType.WARNING);
        rentAlert.setTitle("Mandatory Rent Payment");
        rentAlert.setHeaderText("PAY RENT! $" + rent);
        rentAlert.setContentText(player.getName() + " landed on " + owner.getName() + "'s " + squareType.toLowerCase() + " (" + square.getName() + "). Payment is mandatory.");
        rentAlert.getButtonTypes().setAll(ButtonType.OK);
        styleDialog(rentAlert);
        rentAlert.showAndWait();

        // Pay rent
        if (player.deductMoney(rent)) {
            owner.addMoney(rent);
        } else {
            // Bankruptcy: pay what you can
            int moneyToPay = player.getMoney();
            owner.addMoney(moneyToPay);
            player.addMoney(-moneyToPay);
        }
        refreshAllPlayersMoney();

        // Buyout Opportunity (Property only, not Landmark, not Island)
        if (square instanceof Property && player.getMoney() > 0) {
            Property property = (Property) square;
            if (!property.isLandmark()) {
                int buyoutPrice = (int)(property.getPrice() * 1.5);
                if (player.getMoney() >= buyoutPrice) {
                    Alert buyoutAlert = new Alert(Alert.AlertType.CONFIRMATION);
                    buyoutAlert.setTitle("Buyout Opportunity");
                    buyoutAlert.setHeaderText("Buyout " + property.getName() + "?");
                    buyoutAlert.setContentText("Price: $" + buyoutPrice + ". Do you want to buy it?");
                    styleDialog(buyoutAlert);

                    Optional<ButtonType> buyoutResult = buyoutAlert.showAndWait();
                    if (buyoutResult.isPresent() && buyoutResult.get() == ButtonType.OK) {
                        if (player.deductMoney(buyoutPrice)) {
                            property.getOwner().addMoney(buyoutPrice);
                            property.setOwner(player);
                            property.setLandmark(false);
                            updateSquareBox(property);
                            refreshAllPlayersMoney();
                            System.out.println("✅ " + player.getName() + " bought out " + property.getName());
                        }
                    }
                }
            }
        }

        endTurn(player, rollButton);
    }
}